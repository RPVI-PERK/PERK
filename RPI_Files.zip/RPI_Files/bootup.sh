cd /home/perk/RPI_Files
bash setup_tlv.sh
bash speaker.sh
pyperk/bin/python transliteration.py